package com.example.coursemanager.ui.theme

import androidx.compose.material3.Typography

val AppTypography = Typography()
